package com.sist.web.dao;

import org.springframework.stereotype.Repository;

import com.sist.web.model.User;

@Repository("userDao")
public interface UserDao {
	//조회
	public User userSelect(String userId);
	
	//등록
	public int userInsert(User user);
	
	//수정
}
