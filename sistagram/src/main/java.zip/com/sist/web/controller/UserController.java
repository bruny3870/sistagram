package com.sist.web.controller;

import java.util.Random;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sist.common.util.StringUtil;
import com.sist.web.model.Response;
import com.sist.web.model.User;
import com.sist.web.service.UserService;
import com.sist.web.util.CookieUtil;
import com.sist.web.util.HttpUtil;
import com.sist.web.util.JsonUtil;

@Controller("userController")
public class UserController {
	private static Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private JavaMailSender mailSender;
	
	//쿠키
	@Value("#{env['auth.cookie.name']}")
	private String AUTH_COOKIE_NAME;
	
	//로그인
	@RequestMapping(value="/user/login", method=RequestMethod.POST)
	@ResponseBody
	public Response<Object> login(HttpServletRequest request, HttpServletResponse response) {
		Response<Object> res = new Response<Object>();
		
		String userId = HttpUtil.get(request, "userId");
		String userPwd = HttpUtil.get(request, "userPwd");
		String userEmail = HttpUtil.get(request, "userEmail");
		
		if (!StringUtil.isEmpty(userId) && !StringUtil.isEmpty(userPwd)) {
			User user = userService.userSelect(userId);
			
			if (user != null) {
				if (StringUtil.equals(user.getUserPwd(), userPwd)) {
					CookieUtil.addCookie(response, "/", -1, AUTH_COOKIE_NAME, CookieUtil.stringToHex(userId));
					res.setResponse(0, "성공");
				}
				
				else {
					res.setResponse(-1, "비밀번호 잘못");
				}
			}
			
			else {
				res.setResponse(404, "회원 없음");
			}
		}
		
		else {
			res.setResponse(400, "잘못 요청");
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("[UserController] /user/login response \n" + JsonUtil.toJsonPretty(res));
		}
		
		return res;
	}
	
	//로그아웃
	
	
	//회원가입 화면
	@RequestMapping(value="/user/signUp", method=RequestMethod.GET)
	public String signUp(HttpServletRequest request, HttpServletResponse response) {
		return "/user/signUp";
	}
	
	//아이디 중복체크
	@RequestMapping(value="/user/idCheck", method=RequestMethod.POST)
	@ResponseBody
	public Response<Object> idCheck(HttpServletRequest request, HttpServletResponse response) {
		Response<Object> res = new Response<Object>();
		
		String userId = HttpUtil.get(request, "userId");
		
		if (!StringUtil.isEmpty(userId)) {
			if (userService.userSelect(userId) == null) {
				res.setResponse(0, "성공");
			}
			
			else {
				res.setResponse(100, "아이디 중복");
			}
		}
		
		else {
			res.setResponse(400, "잘못 요청");
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("[UserController] /user/idCheck response \n" + JsonUtil.toJsonPretty(res));
		}
		
		return res;
	}
	
	//회원가입
	@RequestMapping(value="/user/signUpProc", method=RequestMethod.POST)
	@ResponseBody
	public Response<Object> signUpProc(HttpServletRequest request, HttpServletResponse response) {
		Response<Object> res = new Response<Object>();
		
		String userId = HttpUtil.get(request, "userId");
		String userPwd = HttpUtil.get(request, "userPwd");
		String userName = HttpUtil.get(request, "userName");
		String userEmail = HttpUtil.get(request, "userEmail");
		
		if (!StringUtil.isEmpty(userId) && !StringUtil.isEmpty(userPwd) 
				&& !StringUtil.isEmpty(userName) && !StringUtil.isEmpty(userEmail)) {
			if (userService.userSelect(userId) == null) {
				User user = new User();
				
				user.setUserId(userId);
				user.setUserPwd(userPwd);
				user.setUserName(userName);
				user.setUserEmail(userEmail);
				user.setStatus("Y");
				
				if (userService.userInsert(user) > 0) {
					res.setResponse(0, "성공");
				}
				
				else {
					res.setResponse(500, "서버 에러");
				}
			}
			
			else {
				res.setResponse(100, "아이디 중복");
			}
		}
		
		else {
			res.setResponse(400, "잘못 요청");
		}
		
		if (logger.isDebugEnabled()) {
			logger.debug("[UserController] /user/signUp response \n" + JsonUtil.toJsonPretty(res));
		}
		
		return res;
	}
	
	//비밀번호찾기 화면
	@RequestMapping(value="/user/findPw", method=RequestMethod.GET)
	public String findPw(HttpServletRequest request, HttpServletResponse response) {
		return "/user/findPw";
	}
	
	//메일보내기
	@RequestMapping(value="/user/mailCheck", method=RequestMethod.GET)
	@ResponseBody
	public String mailCheck(String email) throws Exception {
		System.out.println("이메일 데이터 전송 확인");  //확인용
		System.out.println("인증 이메일 : " + email);  
		
		
		//인증번호 생성
		Random random = new Random();
		int checkNum = random.nextInt(888888) + 111111;
		System.out.println("인증번호 :"+ checkNum);
		
		
		//이메일 전송 내용
		String setFrom = "junghooh15@gmail.com"; //발신 이메일
		String toMail = email;         //받는 이메일
		String title = "TEST 회원가입 인증 이메일 입니다.";
		String content = 
						"인증 번호는 " + checkNum + "입니다." + 
						"해당 인증번호를 인증번호 확인란에 기입하여 주세요.";
		//이메일 전송 코드
		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(message, true, "utf-8");
			helper.setFrom(setFrom);
			helper.setTo(toMail);
			helper.setSubject(title);
			helper.setText(content,true);
			mailSender.send(message);
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		
		String num = Integer.toString(checkNum); // ajax를 뷰로 반환시 데이터 타입은 String 타입만 가능
		
		return num; // String 타입으로 변환 후 반환
	}
}
